<head>
<link rel="stylesheet" type="text/css" href="../css/bands.css">
<link rel="stylesheet" type="text/css" href="../css/main.css">

<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" type="text/css" href="http://watevermusic.com/templates/gk_rockwall/css/layout.css">
<link rel="stylesheet" type="text/css" href="http://watevermusic.com/templates/gk_rockwall/css/template.css">
<link rel="stylesheet" type="text/css" href="http://watevermusic.com/templates/gk_rockwall/css/k2.css">
<link rel="stylesheet" type="text/css" href="http://watevermusic.com/templates/gk_rockwall/css/menu/menu.css" />
<link rel="stylesheet" type="text/css" href="http://watevermusic.com/templates/gk_rockwall/css/override.css">


</head>
<body>
<div id="gkMenuWrapper">
				<div class="gkPage">
					<div id="gkMainMenu" class="gkPage">
						<nav id="gkExtraMenu" class="gkMenu">
							<ul class="gkmenu level0">
								<li class="first"><a href="http://watevermusic.com/" class=" first active" id="menu640" title="home" onmouseover="">watevermusic.com</a></li>
								
							</ul>
						</nav>
					</div>		
				</div>
			</div>
<div id="gkTop" class="noheader">
	<div class="gkPage" style="margin: 2em 0 0 0 !important;">
		<h1 class="gkLogo" style="padding:5px;">
	     	<a href="http://wemdb.in/ " id="gkLogo">
	        <img src="/images/webdb-1.png" alt="watevermusic.com">
	     	</a>
     		</h1>
     	</div>		
</div>
	<div class="noImage">
		<img src="/images/db_no_image.jpg">
	</div>

	<footer id="gkFooter" class="gkPage">
	<div>
				
				
				<p id="gkCopyrights">© 2013, watevermusic.com. All Rights Reserved.</p>
				
			</div>
</footer>
</body>